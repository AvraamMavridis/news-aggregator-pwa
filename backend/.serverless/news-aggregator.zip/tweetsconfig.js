module.exports = [
  {
    screen_name: 'doctvgr',
    source: 'DOC TV',
  },
  {
    screen_name: 'ThePressProject',
    source: 'ThePressProject',
  },
  {
    screen_name: 'amna_news',
    source: 'ΑΠΕ-ΜΠΕ',
  },
  {
    screen_name: 'CNNgreece',
    source: 'CNNgreece',
  },
  {
    screen_name: 'protagongr',
    source: 'Protagon',
  },
  {
    screen_name: 'lifomag',
    source: 'Lifo',
  },
  {
    screen_name: 'ta_nea',
    source: 'ΤΑ ΝΕΑ',
  },
];